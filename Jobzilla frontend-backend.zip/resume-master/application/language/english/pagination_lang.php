<?php if (!defined('BASEPATH'))   exit('No direct script access allowed');

$lang['pagination_last_link'] = "Last &rsaquo;";
$lang['pagination_first_link'] = "&lsaquo; First";
$lang['pagination_next_link'] = "&gt;";
$lang['pagination_prev_link'] = "&lt;";
