<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
 * Database table prefix
 */
$config['site_name'] = 'Ci_Dashboard';
$config['from_email_address'] = 'ci_dashboard@boodev.co';

/*
 * Xml file path which contain database table name and table fields
 */
$config['xml_file_path'] = "application/tables";


