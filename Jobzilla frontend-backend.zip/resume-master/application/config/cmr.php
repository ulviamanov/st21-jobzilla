<?php

$config["cmr_image_url_red"] = CDN_URL . "img/cmr_red.jpg";
$config["cmr_image_url_blue"] = CDN_URL . "img/cmr_blue.jpg";
$config["cmr_image_url_green"] = CDN_URL . "img/cmr_green.jpg";
$config["cmr_image_url_black"] = CDN_URL . "img/cmr_black.jpg";
$config["cmr_image_url_last_page"] = CDN_URL . "img/cmr_last_page.png";