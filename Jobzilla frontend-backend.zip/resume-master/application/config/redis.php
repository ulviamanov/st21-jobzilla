<?php

defined('BASEPATH') OR exit('No direct script access allowed');



$config['socket_type'] = 'tcp'; //`tcp` or `unix`

$config['socket'] = '/var/run/redis.sock'; // in case of `unix` socket type

// $config['host'] = '127.0.0.1';
$config['host'] = 'dhsslistview.qfffvi.0001.euw1.cache.amazonaws.com';

$config['password'] = NULL;

$config['port'] = 6379;

$config['timeout'] = 0;