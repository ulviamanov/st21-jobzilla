<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['ShopUrl'] = 'endroit-demo.myshopify.com';
$config['shopify_ApiKey'] = '59ef8a236dd3972a426e0e8240ba292a';
$config['shopify_Password'] = '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';

