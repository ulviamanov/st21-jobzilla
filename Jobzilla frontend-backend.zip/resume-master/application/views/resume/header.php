
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="EN"> <!--<![endif]-->


<!-- Mirrored from app.coolfreecv.com/?lang=en&file=11 by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 02 Jul 2021 01:46:25 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head> 


	<meta charset="utf-8">
	<meta name="description" content="Download Free CV (resume) Samples Doc / Docx or Use builder, creator, maker. Your Professional CV Ready in 10 Minutes?.">
	<title>Creator CV / Resume</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" href=<?php echo base_url()."resume/assets/css/bootstrap.min.css"?>>
	<link rel="stylesheet" href=<?php echo base_url()."resume/assets/css/flexslider.css"?>>
	<link rel="stylesheet" href=<?php echo base_url()."resume/assets/css/main.css"?>>

	<link rel="stylesheet" href=<?php echo base_url()."resume/assets/css/responsive.css"?>>
	<link rel="stylesheet" href=<?php echo base_url()."resume/assets/css/animate.min.css"?>>

	<link rel="stylesheet" href=<?php echo base_url()."resume/font-awesome/4.4.0/css/font-awesome.min.css"?>>

	<link href=<?php echo base_url()."resume/assets/css/kreator.css"?> rel="stylesheet">

	<meta name="robots" content="noindex, follow" />
	<meta name="googlebot" content="noindex, follow" /> 


	<link rel="stylesheet" href=<?php echo base_url()."resume/jquery-ui.css"?> />
	<script src=<?php echo base_url()."resume/jquery-1.9.1.js"?>></script>
	<script src=<?php echo base_url()."resume/jquery-ui.js"?>></script>





	<script src=<?php echo base_url()."resume/assets/js/addang.js"?>></script> 
	<script src=<?php echo base_url()."resume/assets/js/sc.js"?>></script>
	<script src=<?php echo base_url()."resume/assets/js/bulet.js"?>></script> <!-- 2017 -->
	<script src=<?php echo base_url()."resume/assets/js/kreatorsc.js"?>></script>

	<link rel="shortcut icon" type="image/x-icon" href=<?php echo base_url()."img/jobzilla.png"?> />

	<script language="javascript">
		function DeleteInfo(Comunicat,Url)
		{
			if(confirm(Comunicat))
			{
				window.location = Url;
			}
		}	
	</script>

</head>

<body>
	<section id="work-detail" class="work-detail">
		<div class="container-fluid">







			<section class="tophead" role="tophead" style="padding-bottom:12px; margin-top:15px;"> 
				<!-- Navigation Section -->

				<div class="header-content clearfix"> <a class="logo" href="<?php echo base_url()?>" rel="noreferrer"><img src=<?php echo base_url()."img/jobzilla.png"?> alt="logo" width=150></a>
					<nav class="navigation" role="navigation" style="margin-top:7px;">
						<ul class="primary-nav">




							<li><a href="<?php echo base_url()."dashboard/uploadCv"?>" rel="noreferrer" >Upload CV</a></li>	
							<li><a href="<?php echo base_url()."dashboard/jobSearch"?>" rel="noreferrer">JOB Search</a></li>

							<li><a href="<?php echo base_url()."dashboard/coverLetter"?>" rel="noreferrerr">Cover Letter Creator</a></li>	
							
						</ul>
					</nav>
					<a href="#" class="nav-toggle">Menu<span></span></a> </div>



					<!-- Navigation Section --> 
				</section>

