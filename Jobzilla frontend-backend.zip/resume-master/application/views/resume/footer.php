


<!-- footer section -->
<footer id="contact" class="footer" style="border-top:1px solid #ccc; margin-top:30px;">
  <div class="container-fluid">
    <div class="col-md-4 left">
      
    </div>
   
    <div class="col-md-2 left">
     
    </div>
    <!-- <div class="col-md-6 right">
      <p>Copyright &copy; 2021 &nbsp; <a href="http://www.coolfreecv.com/privacy-policy" target="_blank" rel="nofollow"><u>Privacy policy while using the online wizard.</u></a></p>
    </div> -->
  </div>
</footer>
<!-- footer section --> 

</div>
</section>
 
 
<script src=<?php echo base_url()."resume/assets/js/bootstrap.min.js"?>></script> 
<script src=<?php echo base_url()."resume/assets/js/jquery.flexslider-min.js"?>></script> 
<script src=<?php echo base_url()."resume/assets/js/retina.min.js"?>></script> 
<script src=<?php echo base_url()."resume/assets/js/modernizr.js"?>></script> 
<script src=<?php echo base_url()."resume/assets/js/main.js"?>></script>

 

</body>

<!-- Mirrored from app.coolfreecv.com/?lang=en&file=11 by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 02 Jul 2021 01:46:52 GMT -->
</html>