// praca
             function bulet1() {
                var textarea   = document.getElementById("text1");
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + " • " + selection + "" + afterSelection;
                return false;
             } 
			  function bulet2() {
                var textarea   = document.getElementById('text2');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			 function bulet3() {
                var textarea   = document.getElementById('text3');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet4() {
                var textarea   = document.getElementById('text4');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet5() {
                var textarea   = document.getElementById('text5');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet6() {
                var textarea   = document.getElementById('text6');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet7() {
                var textarea   = document.getElementById('text7');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet8() {
                var textarea   = document.getElementById('text8');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet9() {
                var textarea   = document.getElementById('text9');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet10() {
                var textarea   = document.getElementById('text10');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet11() {
                var textarea   = document.getElementById('text11');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet12() {
                var textarea   = document.getElementById('text12');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet13() {
                var textarea   = document.getElementById('text13');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet14() {
                var textarea   = document.getElementById('text14');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function bulet15() {
                var textarea   = document.getElementById('text15');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			   function bulet16() {
                var textarea   = document.getElementById('text16');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			   function bulet17() {
                var textarea   = document.getElementById('text17');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			   function bulet18() {
                var textarea   = document.getElementById('text18');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			   function bulet19() {
                var textarea   = document.getElementById('text19');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			   function bulet20() {
                var textarea   = document.getElementById('text20');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			    function bulet21() {
                var textarea   = document.getElementById('text21');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  
// Edukacja
	   
	                function kropka1() {
                var textarea   = document.getElementById("zawartosc1");
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + " • " + selection + "" + afterSelection;
                return false;
             } 
			  function kropka2() {
                var textarea   = document.getElementById('zawartosc2');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			 function kropka3() {
                var textarea   = document.getElementById('zawartosc3');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka4() {
                var textarea   = document.getElementById('zawartosc4');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka5() {
                var textarea   = document.getElementById('zawartosc5');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka6() {
                var textarea   = document.getElementById('zawartosc6');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka7() {
                var textarea   = document.getElementById('zawartosc7');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka8() {
                var textarea   = document.getElementById('zawartosc8');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka9() {
                var textarea   = document.getElementById('zawartosc9');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka10() {
                var textarea   = document.getElementById('zawartosc10');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka11() {
                var textarea   = document.getElementById('zawartosc11');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka12() {
                var textarea   = document.getElementById('zawartosc12');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka13() {
                var textarea   = document.getElementById('zawartosc13');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka14() {
                var textarea   = document.getElementById('zawartosc14');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  function kropka15() {
                var textarea   = document.getElementById('zawartosc15');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			   function kropka16() {
                var textarea   = document.getElementById('zawartosc16');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			   function kropka17() {
                var textarea   = document.getElementById('zawartosc17');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			   function kropka18() {
                var textarea   = document.getElementById('zawartosc18');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			   function kropka19() {
                var textarea   = document.getElementById('zawartosc19');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
			  
// zainteresowania
			  function zainteresowania() {
                var textarea   = document.getElementById('zaintere');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 
// umiejętnosci
			  function umiejetnosci() {
                var textarea   = document.getElementById('umiej');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + ' • ' + selection + '' + afterSelection;
                return false;
             } 	





// cover letter
			  function addtxt() {
               var textarea   = document.getElementById('totu');
				var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
				var selectionStart = textarea.selectionStart;
				var selectionEnd = textarea.selectionEnd;
				var beforeSelection = textarea.value.substring(0, selectionStart);
				var selection = textarea.value.substring(selectionStart, selectionEnd);
				var afterSelection = textarea.value.substr(selectionEnd);
                textarea.value = beforeSelection + 'Dear [Mr./Ms.] [First Name] [Last Name],'+selection+'\n\n'+selection+'My name is [your name]. I am thrilled to be applying for the [position] role in your company. After reviewing your job description, it’s clear that you’re looking for an enthusiastic applicant that can be relied upon to fully engage with the role and develop professionally in a self-motivated manner. Given these requirements, I believe I am the perfect candidate for the job. '+selection+'\n\n'+selection+'I am a [insert positive trait] professional [insert your degree] who has been consistently praised as [insert positive trait] by my peers. Over the course of my career, I have developed proven [insert 1-3 soft skills] skills, which I hope to leverage into the [position] role at your company. '+selection+'\n\n'+selection+'After reviewing my resume, I hope you will agree that I am the type of positive and driven candidate that you are looking for. I am excited to elaborate on how my specific skills and abilities will benefit your organization. Please contact me at [PHONE] or via email at [EMAIL] to arrange for a convenient meeting time. '+selection+'\n\n'+selection+'Thank you for your consideration, and I look forward to hearing from you soon. '+selection+'\n\n'+selection+'Sincerely,' + afterSelection;
                return false;
             } 			




			function clean() {
			var textarea = document.getElementById('totu');
			var select     = (textarea.value).substring(textarea.selectionStart, textarea.selectionEnd);
			var selectionStart = textarea.selectionStart;
			var selectionEnd = textarea.selectionEnd;
			var beforeSelection = textarea.value.substring(0, selectionStart);
			var selection = textarea.value.substring(selectionStart, selectionEnd);
			var afterSelection = textarea.value.substr(selectionEnd);
			textarea.value = '';
			return false;
			}
			
			
			function cleanphoto() {
			var img = document.getElementById('myImg');
			img.src = '';
			var input = document.getElementById('InputmyImg');
			input.value = '';
			document.getElementById('linkRED').innerHTML="";
			document.getElementById('linkRED').style.display="none";
			document.getElementById('noname').innerHTML='<img id="noname" style="margin-top:-20px" src="//app.coolfreecv.com/images/noname.jpg">';
			
			
			return false;
			}
			 
			 
			function wstaw(){
			//document.getElementsByTagName("div")[14].innerHTML="Remove Photo";
			//document.getElementsByTagName("div")[13].innerHTML="";
			
			setTimeout("document.getElementById('linkRED').style.display=''",5000);
			document.getElementById('linkRED').innerHTML="Remove Photo";
			document.getElementById('noname').innerHTML='';
			return false;
			}
			
			
			
			 