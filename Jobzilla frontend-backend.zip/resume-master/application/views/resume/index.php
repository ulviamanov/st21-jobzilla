

<?php $this->load->view("resume/header"); ?>

<div class="row" style="margin-bottom:20px"> <div class="col-md-3"><div id="x">



<script async src="../pagead2.googlesyndication.com/pagead/js/f.txt"></script>
<!-- banner300x600xCFC -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:600px"
     data-ad-client="ca-pub-8957905260244828"
     data-ad-slot="5638729864"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>


&nbsp;
<br/>
&nbsp;
</div> </div> <div class="col-md-9">
<div class="row mypage"> <div class="col-md-12">
<br/><br/>
<form  action="https://app.coolfreecv.com/coverletter/pdf-cl-11.php"  method="post" enctype="multipart/form-data" style="font-size: 11px; font-family: verdana; "> 

<div class="row"> 		 
<div  class="col-md-12"  >	 
		
<table style="width:85%">
 			<tr>
<td colspan="2" style="width:180px;"><h1>YOUR CONTACT DETAILS</h1></td>  
</tr>
			<tr>
<td style="width:180px;"><p>Name&nbsp;</p></td> <td><p><input type="text" name="name" class="inputstle" style="max-width:400px;"  /></p></td>
</tr>
		<tr>
<td style="width:180px;" valign="top"><p>Address&nbsp;</p></td> <td>
<p><input type="text" name="address"  class="inputstle" style="max-width:400px;" placeholder="Street Address, City, State/Province Zip"/></p></td>
</tr>


<tr>
<td><p>Phone</p></td> <td><p><input type="text" name="phone"  class="inputstle" style="max-width:400px;"/></p></td>
</tr>
<tr>
<td><p>Email</p></td> <td><p><input type="text" name="email" class="inputstle" style="max-width:400px;" /></p></td>
</tr>
 

 </table>
<hr>
 
 <table style="width:85%">
			<tr>
<td style="width:180px;"><p>Date &nbsp;</p></td> <td><p><input type="text" name="date" class="inputstle" style="max-width:400px;" value="02 July, 2021" /></p></td>
</tr> 
 

 </table>
 
<hr>
 
 
 <table style="width:85%">
 
 			<tr>
<td style="width:180px;"><h1>RECIPIENT</h1></td> <td> &nbsp;</td>
</tr>
			<tr>
<td style="width:180px;"><p>Name of Person & Title &nbsp;</p></td> <td><p><input type="text" name="namerecipment" class="inputstle" style="max-width:400px;" /></p></td>
</tr><tr>
<td><p>Company / Organization</p></td> <td><p><input type="text" name="companyname"  class="inputstle" style="max-width:400px;"/></p></td>
</tr>
<tr>
<td valign="top"><p>Address</p></td> <td><textarea  style="max-width:400px; height:42px;" type="text" name="addressrecipment" class="inputstle" placeholder="Street Address, 
City, State/Province Zip" /></textarea></td>
</tr>
 

 </table>
  
 
  
 </div></div>

 <div style="clear:both;"></div>
 
<hr>
<h1>CONTENTS OF A COVER LETTER <a class="dymekbig" style="z-index:100"><img src="images/infocoverletter.png" style="vertical-align:middle; width:32px; height:32px;" ><span>

Dear Mr./Ms.____________:
<br/><br/>
INTRODUCTION: State the reason for writing. Name the specific position, or type of work for which
you are applying. (Mention the resource used in finding out about the opening/company: Career
Services, news media, friend, and faculty, if appropriate).
<br/><br/>
BODY: Explain why you are interested in working for that employer, or in that field of work, and most
importantly what your qualifications are (academic background, work experience, personal skills). Point
out achievements that relate to the field and why you enjoy that work. Refer the reader to the enclosed
resume, application, and/or portfolio.
<br/><br/>
CLOSING: Indicate your desire for an interview. State that you will call on a specific day to see if an
interview can be arranged at this person’s convenience. (If you will be in their geographic vicinity on a
certain day, stress the importance of setting up an interview on that day).
<br/><br/>
Sincerely,

<br/></b></span>
</a></h1> 


<input type="button" value="Add a Sample Cover Letter" onclick="addtxt()" /> &nbsp; &nbsp; &nbsp;<input type="button" value="Delete Content" onclick="clean()" />

<br/>
<br/>
         
<textarea id="totu"  style="height:350px; width:85%; border: 1px solid #ccc; border-radius: 4px; font-size: 13px;" type="text" name="contentcoverletter"    /></textarea>
		
		<hr>
<table style="width:85%">
 
<td style="width:180px;" valign="top"><p>Signature</p></td> <td><p><input type="text" name="signature" class="inputstle" style="max-width:400px;"  placeholder="[Your First Name] [Your Last Name]" /></p></td>
</tr>
 

 </table>
		
		
		<p><br/><input value="DOWNLOAD PDF" type="Submit"  class="btn btn-info" style="font-size:19px; font-weight:bold;"></p>
		</form>
</div></div> </div></div>




<div class="row" style="margin-top:30px">
<div class="col-md-3"> 
</div>
<div class="col-md-9">


<div class="row footerStyle">

<div class="col-md-4 footerBorderLeft">
<ul><li><a  class="footerLink" href="http://www.coolfreecv.com/skills-section-in-CV" rel="noreferrer">Skills section in CV</a></li> <li><a  class="footerLink" href="http://www.coolfreecv.com/professional-cv-tips" rel="noreferrer">Professional CV Tips</a></li></ul></div>

<div class="col-md-4 footerBorderLeft" >
<ul><li><a class="footerLink" href="http://www.coolfreecv.com/interview" rel="noreferrer">How to prepare for a recruitment interview</a></li> <li><a class="footerLink" href="http://www.coolfreecv.com/perfect-cv" rel="noreferrer">Perfect CV</a></li></ul>
</div>

<div class="col-md-4 footerBorderLeft">
</div>
</div>
</div>

</div>


<?php $this->load->view("resume/footer"); ?>
