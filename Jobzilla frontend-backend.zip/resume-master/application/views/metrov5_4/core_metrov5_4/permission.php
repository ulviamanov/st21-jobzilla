<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
?>
<div class="row">
	<div class="col-lg-12">
		<h1 class=""></h1>
	</div>
	<!-- /.col-lg-12 -->
</div>
<div class="alert alert-danger" role="alert">
	<?php echo $no_permission_message; ?>
</div>