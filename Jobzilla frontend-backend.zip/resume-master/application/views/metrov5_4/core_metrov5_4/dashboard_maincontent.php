<?php

if (! defined('BASEPATH'))
    exit('No direct script access allowed');
?>
<div class="m-content">	
		<?php echo $content; ?>
</div>
