<?php
if (! defined ( 'BASEPATH' ))
    exit ( 'No direct script access allowed' ); ?>
<html>
<head>

</head>
<body>
<div>

<?php 
       
    echo $message;

?>
</div>
</body>
</html>
