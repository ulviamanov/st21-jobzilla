<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<tr>
    <td valign="top" colspan="2" style="color:#333333;">
        <?php echo dashboard_lang('_REGARDS'); ?>
    </td>
</tr>

<tr>
    <td valign="top" colspan="2" style="color:#333333;">
        <?php echo dashboard_lang('_PORTAL_TEAM'); ?>
    </td>
</tr>
</tbody>
</table>
</td>
</tr>
</table>
</div>
</body>
</html>
