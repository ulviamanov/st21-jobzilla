<?php
if (! defined('BASEPATH'))
    exit('No direct script access allowed');
boo2_render_edit_top();
?>
