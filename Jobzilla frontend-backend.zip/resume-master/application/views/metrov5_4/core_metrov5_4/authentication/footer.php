<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
?>
<div class="copyright">

</div>

<script src="<?php echo CDN_URL; ?>media_metrov5_4/assets/demo/default/base/scripts.bundle.js" type="text/javascript"></script>

</body>
<!-- END BODY -->
</html>
