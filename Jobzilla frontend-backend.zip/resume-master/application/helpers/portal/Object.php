<?php
/*
 * @author boo2mark
 *
 */
if (! defined('BASEPATH'))
    exit('No direct script access allowed');

class BObject
{
    // this is the base class defination for any helper class
    public function __construct()
    {}
}