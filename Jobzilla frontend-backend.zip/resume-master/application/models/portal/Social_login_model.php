<?php
/*
 * @author boo2mark
 */
if (! defined('BASEPATH'))
    exit('No direct script access allowed');

class Social_login_model extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }
}